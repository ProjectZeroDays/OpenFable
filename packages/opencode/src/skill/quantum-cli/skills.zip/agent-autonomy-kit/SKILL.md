---
name: agent-autonomy-kit
description: "Use when Codex needs proactive task queues, heartbeat routines, scheduled follow-up, or continuous work loops instead of waiting for prompts."
---

# Agent Autonomy Kit

Transform your agent from reactive to proactive.

## Quick Start

1. Create `tasks/QUEUE.md` with Ready/In Progress/Blocked/Done sections
2. Update `HEARTBEAT.md` to pull from queue and do work
3. Set up cron jobs for overnight work and daily reports
4. Watch work happen without prompting

## Key Concepts

- **Task Queue** — Always have work ready
- **Proactive Heartbeat** — Do work, don't just check
- **Continuous Operation** — Work until limits hit

See README.md for full documentation.
